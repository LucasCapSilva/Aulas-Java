
export class Categoria{
        
        public id:number
        public descricao:string
  
}